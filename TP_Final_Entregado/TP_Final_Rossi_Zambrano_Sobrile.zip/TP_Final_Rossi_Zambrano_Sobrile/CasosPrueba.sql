----------  PUNTO 1 --------------
select dbo.f_Valida_Normas ('alumno', 'T')		--  1
select dbo.f_Valida_Normas ('TB_Notas', 'T')	-- -1
select dbo.f_Valida_Normas ('GEN_alumno', 'T')	--  0

select dbo.f_Valida_Normas ('IX_INDejemplo', 'I')			-- -1
select dbo.f_Valida_Normas ('ixX_ARQ_Tabla1_Indice1', 'I')	--  1
select dbo.f_Valida_Normas ('ix_GEN_Tabla2_Indice2', 'I')	--  0

select dbo.f_Valida_Normas ('FK_WEB_general_alumnos', 'FK')		--  1
select dbo.f_Valida_Normas ('FK_foraneaEj', 'FK')				-- -1
select dbo.f_Valida_Normas ('FK_GEN_Tabla2_MKT_Tabla3', 'FK')	--  0

select dbo.f_Valida_Normas ('PR_clave', 'PK')					-- -1
select dbo.f_Valida_Normas ('PK_MKT_Registro_intIDLegajo', 'PK')--  0
select dbo.f_Valida_Normas ('PK_ARQ_Tabla1_intIdCampo1', 'PK')	--  1

select dbo.f_Valida_Normas ('CK_decCampo5', 'C')		--  0
select dbo.f_Valida_Normas ('CHK_Ejemplo', 'C')			-- -1
select dbo.f_Valida_Normas ('CHK_datCampo3', 'C')		--  1

select dbo.f_Valida_Normas('p_NAN_Procedure3','P'); --No Cumple (1)
select dbo.f_Valida_Normas('p_PVN_Procedure1','P'); --Cumple (0)
select dbo.f_Valida_Normas('p_PVN_Procedure','P'); --No existe (-1)
--
select dbo.f_Valida_Normas('v_ARQ_Vista1','V'); --Existe (0)
select dbo.f_Valida_Normas('VW_ListadoRegistro','V'); --No cumple (1)
select dbo.f_Valida_Normas('VW_ListadoRegi','V'); --No Existe (-1)
--
select dbo.f_Valida_Normas('TRI_ARQ_Tabla1_Trigger1','TR'); --Cumple (0)
select dbo.f_Valida_Normas('TRULI_MKT_Tabla3_Trigger3','TR'); --No Cumple (1)
select dbo.f_Valida_Normas('TRULI_MKT_Tabl_Trigger3','TR'); --No existe (1)
--
select dbo.f_Valida_Normas('UQ_varCampo2','UQ'); --cumple(0)
select dbo.f_Valida_Normas('UQ_varDescripcion_datFechaNac','UQ'); --No cumple(1)
select dbo.f_Valida_Normas('U_varDescripcion_datFechaNac','UQ'); --No Existe(1)
--

----------  PUNTO 2 --------------
exec dbo.p_validar_normativa 'P';
exec dbo.p_validar_normativa 'PK';
exec dbo.p_validar_normativa 'FK';
exec dbo.p_validar_normativa 'T';
exec dbo.p_validar_normativa 'V';
exec dbo.p_validar_normativa 'U';
exec dbo.p_validar_normativa 'C';
exec dbo.p_validar_normativa 'TR';

----------  PUNTO 3 --------------
p_validar_campos 'WEB_notas';
p_validar_campos 'MKT_Tabla3';
p_validar_campos 'ARQ_Tabla1';

