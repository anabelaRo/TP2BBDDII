/* ====================================================== */
/* =================  TP FINAL PUNTO 2  ================= */
/* =                                                    = */
/* =  DEVUELVE TODOS LOS OBJETOS DEL TIPO SOLICITADO  	= */
/* =  QUE NO CUMPLEN CON LA NORMATIVA				  	= */
/* =  PARAMETRIZACI�N:								   == */
/* =  VALIDAR TABLAS: 'T' 							   == */
/* =  VALIDAR PROCEDIMIENTOS: 'P'					   == */
/* =  VALIDAR CLAVES FOR�NEAS:  'FK'				   == */
/* =  VALIDAR CLAVES PRIMARIAS: 'PK'				   == */
/* =  VALIDAR �NDICES: 'I'			 				   == */
/* =  VALIDAR TRIGGERS: 'TR' 						   == */
/* =  VALIDAR UNIQUES: 'U'							   == */
/* =  VALIDAR CHECKS: 'C'							   == */
/* =  VALIDAR VISTAS: 'V'							   == */
/* ====================================================== */

CREATE PROCEDURE p_validar_normativa
	@varTipoObjeto VARCHAR(50)	
AS
BEGIN
	DECLARE @error CHAR(1)
	DECLARE @Num	INT
	DECLARE @Campo_Clave1		VARCHAR(50)
	DECLARE @Campo_Clave2		VARCHAR(50)
	DECLARE @Campo_Clave3		VARCHAR(50)
	DECLARE @Campo_Clave4		VARCHAR(50)
	--
IF (UPPER(@varTipoObjeto) = 'T') /* TABLAS */
BEGIN
				SELECT name as 'Tablas fuera de norma'
				FROM sys.objects
				WHERE TYPE = 'U'
				AND name NOT IN (
										SELECT name
										from sys.objects
										where SUBSTRING( name, 1, 3 ) IN ('ARQ','GEN','MKT','PRT','PVN','RSV','SYA','TMP','WEB') AND
											  SUBSTRING( name, 4, 1) = CHAR(95) 
												AND SUBSTRING( name, 5, 1) = UPPER(SUBSTRING( name, 5, 1) )	
									  )	 
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'P')  /* PROCEDIMIENTOS */
BEGIN
	--
	SELECT name as 'Procedimientos fuera de norma'
	FROM sys.objects
	WHERE TYPE = 'P'
		AND name NOT IN (
								SELECT name
								from sys.objects
								where LEFT( NAME, 2 ) = 'p' + CHAR(95)  AND
										SUBSTRING( name, 3, 3 ) IN ('ARQ','GEN','MKT','PRT','PVN','RSV','SYA','TMP','WEB') AND
										SUBSTRING( name, 6, 1) = CHAR(95) AND 
										SUBSTRING( name, 7, 1) =  UPPER(SUBSTRING( name, 7, 1))
							 ) 
	--
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'V')  /* VISTAS */
BEGIN
	--
	SELECT name as 'Vistas fuera de norma'
	FROM sys.objects
	WHERE TYPE = 'V'
		AND name NOT IN (
								SELECT name
								FROM sys.objects
								WHERE LEFT( NAME, 2 ) = 'v' + CHAR(95)  AND
										SUBSTRING( name, 3, 3 ) IN ('ARQ','GEN','MKT','PRT','PVN','RSV','SYA','TMP','WEB') AND
										SUBSTRING( name, 6, 1) = CHAR(95) AND 
										SUBSTRING( name, 7, 1) =  UPPER(SUBSTRING( name, 7, 1))
							 ) 
	--
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'TR')  /* TRIGGERS */
BEGIN
		--
		DECLARE C_Objetos_Trigger CURSOR FOR
			SELECT obj.name, tab.name
			FROM sys.objects AS obj
					INNER JOIN sys.tables AS tab
						ON obj.parent_object_id = tab.object_id
			WHERE obj.type = 'TR'
		--
		DECLARE @Lista_Triggers TABLE(Nom_Trigger NVARCHAR(max))
		--
		DECLARE @Nombre_Trigger					VARCHAR(250)
		DECLARE @Nom_Tabla						VARCHAR(110)
		--
		DECLARE @Pos_Pri_Guion 					INT
		DECLARE @Nom_Ant_Pri_Guion 			VARCHAR(50)
		DECLARE @Nom_Hasta_Pri_Guion 			VARCHAR(50)
		DECLARE @Primer_Guion					CHAR(1)
		DECLARE @Nom_Despues_Pri_Guion 		VARCHAR(50)
		DECLARE @Prefijo_Tabla 					VARCHAR(50)
		DECLARE @Guion_Des_Prefijo 			CHAR(1)
		DECLARE @NomTabla_Guion_Descripcion VARCHAR(50)
		DECLARE @Ultimo_Guion 					VARCHAR(50)
		DECLARE @Descripcion_Trigger 			VARCHAR(50)
		--
		OPEN C_Objetos_Trigger
			FETCH NEXT FROM C_Objetos_Trigger 
				INTO @Nombre_Trigger, @Nom_Tabla
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				--
				SELECT @Pos_Pri_Guion 					= CHARINDEX( CHAR(95), @Nombre_Trigger )
				SELECT @Nom_Ant_Pri_Guion 				= SUBSTRING( @Nombre_Trigger, 0, @Pos_Pri_Guion )
				SELECT @Nom_Hasta_Pri_Guion 			= SUBSTRING( @Nombre_Trigger, 0, @Pos_Pri_Guion + 1 )
				SELECT @Primer_Guion 					= SUBSTRING( @Nom_Hasta_Pri_Guion, CHARINDEX( CHAR(95), @Nom_Hasta_Pri_Guion ),1 )
				SELECT @Nom_Despues_Pri_Guion 		= REPLACE( @Nombre_Trigger, @Nom_Hasta_Pri_Guion, '' )
				SELECT @Prefijo_Tabla 					= SUBSTRING( @Nom_Despues_Pri_Guion, 1, 3 )
				SELECT @Guion_Des_Prefijo 				= SUBSTRING( @Nom_Despues_Pri_Guion, 4, 1 )
				SELECT @NomTabla_Guion_Descripcion 	= REPLACE( @Nom_Despues_Pri_Guion, @Prefijo_Tabla + CHAR(95), '' )
				SELECT @Descripcion_Trigger 			= REPLACE( REPLACE ( @NomTabla_Guion_Descripcion, SUBSTRING( @Nom_Tabla, 5, LEN( @Nom_Tabla ) ), '' ), CHAR(95), '' )
				SELECT @Ultimo_Guion 					= REPLACE( REPLACE( @NomTabla_Guion_Descripcion, SUBSTRING( @Nom_Tabla, 5, LEN( @Nom_Tabla ) ), '' ), @Descripcion_Trigger, '' )
				--
				SELECT  @error = 'N'
				--
				IF	LEFT( @Nombre_Trigger, 2 ) = 'TR' AND
					LEN( REPLACE( @Nom_Ant_Pri_Guion, 'TR', '') ) <= 3 AND
					@Primer_Guion = CHAR(95)
				BEGIN
					--
					DECLARE @letra_1 CHAR(1) 
					DECLARE @letra_2 CHAR(1)
					DECLARE @letra_3 CHAR(1)
					--
					SELECT @letra_1 = SUBSTRING( REPLACE( @Nom_Ant_Pri_Guion, 'TR', ''),1, 1)
					SELECT @letra_2 = SUBSTRING( REPLACE( @Nom_Ant_Pri_Guion, 'TR', ''),2, 1)
					SELECT @letra_3 = SUBSTRING( REPLACE( @Nom_Ant_Pri_Guion, 'TR', ''),3, 1)
					--
					IF @letra_1 NOT IN ('I','D','U')
					BEGIN
						SELECT @error = 'S'
					END
					ELSE
					BEGIN
						IF @letra_2 != ''
						BEGIN
							IF @letra_2 NOT IN('I','D','U') OR @letra_2 = @letra_1
							BEGIN
								SELECT @error = 'S'
							END
							ELSE
							BEGIN
								IF @letra_3 != ''
								BEGIN
									IF @letra_3 NOT IN('I','D','U') OR @letra_3 = @letra_1 OR @letra_3 = @letra_2
									BEGIN
										SELECT @error = 'S'
									END
								END
							END
						END
					END
				END
				ELSE
				BEGIN
					SELECT @error = 'S'
				END	
				--
				--
				IF @error = 'N'
				BEGIN
					--
					IF	@Ultimo_Guion != CHAR(95) OR
						LEFT( @Descripcion_Trigger, 1 ) != UPPER( LEFT( @Descripcion_Trigger, 1 ) )
					BEGIN
						SELECT @error = 'S'
						--
					END
					--
				END
				--
				--
				IF @error = 'S'
				BEGIN
					INSERT INTO @Lista_Triggers VALUES (@Nombre_Trigger)
				END
				--
				--
				FETCH NEXT FROM C_Objetos_Trigger
					INTO @Nombre_Trigger, @Nom_Tabla
					--
				END
				--
		CLOSE C_Objetos_Trigger
		--
		DEALLOCATE C_Objetos_Trigger
		--
		--
		SELECT Nom_Trigger as 'Triggers fuera de norma' 
		FROM @Lista_Triggers				 
		--						 
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'PK')  /* PRIMARY KEY */
BEGIN
		--
		DECLARE C_Objetos_PK CURSOR FOR
			SELECT obj.name, tab.name
			FROM sys.objects AS obj
					INNER JOIN sys.tables AS tab
						ON obj.parent_object_id = tab.object_id
			WHERE obj.type = 'PK'
		--
		DECLARE @Lista_PrimaryKey TABLE(Nom_Primary NVARCHAR(max))
		--
		DECLARE @Nombre_PK					VARCHAR(250)
		DECLARE @Nom_Tabla_PK				VARCHAR(110)
		--
		DECLARE @Prefijo_Tabla_PK			VARCHAR(150)
		DECLARE @Nom_Despues_Seg_Guion	VARCHAR(150)
		--
		OPEN C_Objetos_PK
			FETCH NEXT FROM C_Objetos_PK 
				INTO @Nombre_PK, @Nom_Tabla_PK
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				--
				SELECT @error = 'N'
				SELECT @Prefijo_Tabla_PK			= SUBSTRING( @Nombre_PK, 4, 3 )
				SELECT @Nom_Despues_Seg_Guion		= REPLACE( @Nombre_PK, LEFT( @Nombre_PK, 7 ), '' )
				--
				IF LEFT( @Nombre_PK, 3 ) != 'PK' + CHAR(95)
				BEGIN
					SELECT @error = 'S'
				END
				ELSE
				BEGIN
					--
					--Obtener los campos clave de la tabla:
					DECLARE C_Armar_PK CURSOR 
					FOR
						SELECT name
						FROM sys.columns 
						WHERE object_id IN (	SELECT object_id 
													FROM sys.objects 
													WHERE name = @Nom_Tabla_PK )
						  AND column_id IN (	SELECT SIK.column_id 
													FROM sys.index_columns SIK 
															INNER JOIN sys.objects SO 
																ON SIK.object_id = SO.object_id
													WHERE SIK.index_id = 1 
													  AND SO.name = @Nom_Tabla_PK )	 
					--
					DECLARE @Nom_Campo_Clave	VARCHAR(250)
					--
					SELECT @Num = 0
					--
					--
					OPEN C_Armar_PK
						FETCH NEXT FROM C_Armar_PK
							INTO @Nom_Campo_Clave
							--
						WHILE @@FETCH_STATUS = 0
						BEGIN
							--
							SELECT @Num = @Num + 1
							--
							IF @Nom_Campo_Clave != ''
							BEGIN
								IF @Num = 1
								BEGIN
									SELECT @Campo_Clave1 = @Nom_Campo_Clave
								END
								ELSE IF @Num = 2
								BEGIN
									SELECT @Campo_Clave2 = @Nom_Campo_Clave
								END
								ELSE IF @Num = 3
								BEGIN
									SELECT @Campo_Clave3 = @Nom_Campo_Clave
								END
								ELSE IF @Num = 4
								BEGIN
									SELECT @Campo_Clave4 = @Nom_Campo_Clave
								END
								--
							END
							--
							FETCH NEXT FROM C_Armar_PK
								INTO @Nom_Campo_Clave
								--
						END
					CLOSE C_Armar_PK
					--
					DEALLOCATE C_Armar_PK
					--
					DECLARE @Nombre_PK_Tentativo1 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo2 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo3 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo4 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo5 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo6 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo7 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo8 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo9 	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo10	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo11	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo12	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo13	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo14	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo15	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo16	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo17	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo18	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo19	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo20	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo21	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo22	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo23	VARCHAR(300)
					DECLARE @Nombre_PK_Tentativo24	VARCHAR(300)
					--
					SELECT @Nombre_PK_Tentativo1 	= ''
					SELECT @Nombre_PK_Tentativo2 	= ''
					SELECT @Nombre_PK_Tentativo3 	= ''
					SELECT @Nombre_PK_Tentativo4 	= ''
					SELECT @Nombre_PK_Tentativo5 	= ''
					SELECT @Nombre_PK_Tentativo6 	= ''
					SELECT @Nombre_PK_Tentativo7 	= ''
					SELECT @Nombre_PK_Tentativo8 	= ''
					SELECT @Nombre_PK_Tentativo9 	= ''
					SELECT @Nombre_PK_Tentativo10	= ''
					SELECT @Nombre_PK_Tentativo11	= ''
					SELECT @Nombre_PK_Tentativo12	= ''
					SELECT @Nombre_PK_Tentativo13	= ''
					SELECT @Nombre_PK_Tentativo14	= ''
					SELECT @Nombre_PK_Tentativo15	= ''
					SELECT @Nombre_PK_Tentativo16	= ''
					SELECT @Nombre_PK_Tentativo17	= ''
					SELECT @Nombre_PK_Tentativo18	= ''
					SELECT @Nombre_PK_Tentativo19	= ''
					SELECT @Nombre_PK_Tentativo20	= ''
					SELECT @Nombre_PK_Tentativo21	= ''
					SELECT @Nombre_PK_Tentativo22	= ''
					SELECT @Nombre_PK_Tentativo23	= ''
					SELECT @Nombre_PK_Tentativo24	= ''
					--
					IF @Campo_Clave4 != ''
					BEGIN
						SELECT @Nombre_PK_Tentativo1  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_PK_Tentativo2  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo3  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_PK_Tentativo4  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo5  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo6  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						--                                                                                                                                                                   
						SELECT @Nombre_PK_Tentativo7  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_PK_Tentativo8  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo9  = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_PK_Tentativo10 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_PK_Tentativo11 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo12 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						--                                                                                                                                                                   
						SELECT @Nombre_PK_Tentativo13 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_PK_Tentativo14 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo15 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_PK_Tentativo16 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_PK_Tentativo17 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo18 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
						--                                                                                                                                                                   
						SELECT @Nombre_PK_Tentativo19 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo20 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo21 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo22 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_PK_Tentativo23 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo24 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					END
					ELSE IF @Campo_Clave3 != ''
					BEGIN
						SELECT @Nombre_PK_Tentativo1 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo2 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo3 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_PK_Tentativo4 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_PK_Tentativo5 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_PK_Tentativo6 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
					END
					ELSE IF @Campo_Clave2 != ''
					BEGIN
						SELECT @Nombre_PK_Tentativo1 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_PK_Tentativo2 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					END
					ELSE IF @Campo_Clave1 != ''
					BEGIN
						SELECT @Nombre_PK_Tentativo1 = 'PK_' + @Nom_Tabla_PK + CHAR(95) + @Campo_Clave1
					END
					--
					IF @Nombre_PK NOT IN (	@Nombre_PK_Tentativo1 ,
													@Nombre_PK_Tentativo2 ,
													@Nombre_PK_Tentativo3 ,
													@Nombre_PK_Tentativo4 ,
													@Nombre_PK_Tentativo5 ,
													@Nombre_PK_Tentativo6 ,
													@Nombre_PK_Tentativo7 ,
													@Nombre_PK_Tentativo8 ,
													@Nombre_PK_Tentativo9 ,
													@Nombre_PK_Tentativo10,
													@Nombre_PK_Tentativo11,
													@Nombre_PK_Tentativo12,
													@Nombre_PK_Tentativo13,
													@Nombre_PK_Tentativo14,
													@Nombre_PK_Tentativo15,
													@Nombre_PK_Tentativo16,
													@Nombre_PK_Tentativo17,
													@Nombre_PK_Tentativo18,
													@Nombre_PK_Tentativo19,
													@Nombre_PK_Tentativo20,
													@Nombre_PK_Tentativo21,
													@Nombre_PK_Tentativo22,
													@Nombre_PK_Tentativo23,
													@Nombre_PK_Tentativo24 )
					BEGIN
						SELECT @error = 'S'
					END
					--
				END
				--
				--
				IF @error = 'S'
				BEGIN
					INSERT INTO @Lista_PrimaryKey VALUES (@Nombre_PK)
				END
				--
				--
				FETCH NEXT FROM C_Objetos_PK
					INTO @Nombre_PK, @Nom_Tabla_PK
					--
				END
				--
		CLOSE C_Objetos_PK
		--
		DEALLOCATE C_Objetos_PK
		--
		--
		SELECT Nom_Primary as 'Primary Key fuera de norma' 
		FROM @Lista_PrimaryKey				 
		--						 
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'U')  /* UNIQUE */
BEGIN
		--
		DECLARE C_Objetos_UQ CURSOR FOR
			SELECT obj.name, tab.name
			FROM sys.objects AS obj
					INNER JOIN sys.tables AS tab
						ON obj.parent_object_id = tab.object_id
			WHERE obj.type = 'UQ'
		--
		DECLARE @Lista_Unique TABLE(Nom_Unique NVARCHAR(max))
		--
		DECLARE @Nombre_UQ					VARCHAR(250)
		DECLARE @Nom_Tabla_UQ				VARCHAR(110)
		--
		OPEN C_Objetos_UQ
			FETCH NEXT FROM C_Objetos_UQ 
				INTO @Nombre_UQ, @Nom_Tabla_UQ
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				--
				SELECT @error = 'N'
				--
				IF LEFT( @Nombre_UQ, 3 ) != 'UQ' + CHAR(95)
				BEGIN
					SELECT @error = 'S'
				END
				ELSE
				BEGIN
					--
					DECLARE @Nom_Campo_Unique			VARCHAR(50)
					DECLARE @Nom_Constraint_UQ			VARCHAR(250)
					DECLARE @Nom_Constraint_UQ_Ant	VARCHAR(250)
					--
					SELECT  @Num = 0
					--
					DECLARE @Primero						INT
					SELECT  @Primero = 1
					--
					SELECT @Campo_Clave1					= ''
					SELECT @Campo_Clave2					= ''
					SELECT @Campo_Clave3					= ''
					SELECT @Campo_Clave4					= ''
					--
					DECLARE @Nombre_UQ_Tentativo1 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo2 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo3 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo4 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo5 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo6 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo7 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo8 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo9 	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo10	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo11	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo12	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo13	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo14	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo15	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo16	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo17	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo18	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo19	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo20	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo21	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo22	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo23	VARCHAR(300)
					DECLARE @Nombre_UQ_Tentativo24	VARCHAR(300)
					--
					SELECT @Nombre_UQ_Tentativo1 	= ''
					SELECT @Nombre_UQ_Tentativo2 	= ''
					SELECT @Nombre_UQ_Tentativo3 	= ''
					SELECT @Nombre_UQ_Tentativo4 	= ''
					SELECT @Nombre_UQ_Tentativo5 	= ''
					SELECT @Nombre_UQ_Tentativo6 	= ''
					SELECT @Nombre_UQ_Tentativo7 	= ''
					SELECT @Nombre_UQ_Tentativo8 	= ''
					SELECT @Nombre_UQ_Tentativo9 	= ''
					SELECT @Nombre_UQ_Tentativo10	= ''
					SELECT @Nombre_UQ_Tentativo11	= ''
					SELECT @Nombre_UQ_Tentativo12	= ''
					SELECT @Nombre_UQ_Tentativo13	= ''
					SELECT @Nombre_UQ_Tentativo14	= ''
					SELECT @Nombre_UQ_Tentativo15	= ''
					SELECT @Nombre_UQ_Tentativo16	= ''
					SELECT @Nombre_UQ_Tentativo17	= ''
					SELECT @Nombre_UQ_Tentativo18	= ''
					SELECT @Nombre_UQ_Tentativo19	= ''
					SELECT @Nombre_UQ_Tentativo20	= ''
					SELECT @Nombre_UQ_Tentativo21	= ''
					SELECT @Nombre_UQ_Tentativo22	= ''
					SELECT @Nombre_UQ_Tentativo23	= ''
					SELECT @Nombre_UQ_Tentativo24	= ''
					--
					DECLARE @existe_UQ 	CHAR(1)
					SELECT @existe_UQ = 'N'
					--
					--Obtener los campos asociados a la UQ:
					DECLARE C_Armar_UQ CURSOR 
					FOR
						--
						SELECT col.constraint_name, col.column_name
						FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE col 
							INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tab
								ON tab.constraint_name = col.constraint_name 
						WHERE tab.table_name = @Nom_Tabla_UQ
						  AND tab.constraint_type = 'UNIQUE' 
						ORDER BY tab.constraint_name
						--
						--
					OPEN C_Armar_UQ
						FETCH NEXT FROM C_Armar_UQ
							INTO @Nom_Constraint_UQ, @Nom_Campo_Unique
							--
						WHILE @@FETCH_STATUS = 0
						BEGIN
							--
							IF @Primero = 1
							BEGIN
								SELECT @Nom_Constraint_UQ_Ant = @Nom_Constraint_UQ
								SELECT @Primero = 0
							END
							--
							IF @Nom_Constraint_UQ = @Nom_Constraint_UQ_Ant
							BEGIN
								--
								SELECT @Num = @Num + 1
								SELECT @Nom_Constraint_UQ_Ant = @Nom_Constraint_UQ
								--
								IF @Nom_Campo_Unique != ''
								BEGIN
									IF @Num = 1
									BEGIN
										SELECT @Campo_Clave1 = @Nom_Campo_Unique
									END
									ELSE IF @Num = 2
									BEGIN
										SELECT @Campo_Clave2 = @Nom_Campo_Unique
									END
									ELSE IF @Num = 3
									BEGIN
										SELECT @Campo_Clave3 = @Nom_Campo_Unique
									END
									ELSE IF @Num = 4
									BEGIN
										SELECT @Campo_Clave4 = @Nom_Campo_Unique
									END
									--
								END
								--
							END
							ELSE
							BEGIN
								SELECT @Primero = 1
								SELECT @Num = 0
								--
							END
							--
							FETCH NEXT FROM C_Armar_UQ
								INTO @Nom_Constraint_UQ, @Nom_Campo_Unique
								--
								IF @Nom_Constraint_UQ != @Nom_Constraint_UQ_Ant
								BEGIN
									SELECT @Primero = 1
									SELECT @Num = 0
									--
									IF @Campo_Clave4 != ''
									BEGIN
										SELECT @Nombre_UQ_Tentativo1  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_UQ_Tentativo2  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo3  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_UQ_Tentativo4  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo5  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo6  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
										--                                                                                                            
										SELECT @Nombre_UQ_Tentativo7  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_UQ_Tentativo8  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo9  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_UQ_Tentativo10 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_UQ_Tentativo11 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo12 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
										--                                                                                                            
										SELECT @Nombre_UQ_Tentativo13 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_UQ_Tentativo14 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo15 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_UQ_Tentativo16 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_UQ_Tentativo17 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo18 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
										--                                                                                                            
										SELECT @Nombre_UQ_Tentativo19 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo20 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo21 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo22 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_UQ_Tentativo23 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo24 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
									END
									ELSE IF @Campo_Clave3 != ''
									BEGIN
										SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo3 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_UQ_Tentativo4 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_UQ_Tentativo5 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_UQ_Tentativo6 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
									END
									ELSE IF @Campo_Clave2 != ''
									BEGIN
										SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
									END
									ELSE IF @Campo_Clave1 != ''
									BEGIN
										SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1
									END
									--
									IF @Nombre_UQ IN (	@Nombre_UQ_Tentativo1 ,
																		@Nombre_UQ_Tentativo2 ,
																		@Nombre_UQ_Tentativo3 ,
																		@Nombre_UQ_Tentativo4 ,
																		@Nombre_UQ_Tentativo5 ,
																		@Nombre_UQ_Tentativo6 ,
																		@Nombre_UQ_Tentativo7 ,
																		@Nombre_UQ_Tentativo8 ,
																		@Nombre_UQ_Tentativo9 ,
																		@Nombre_UQ_Tentativo10,
																		@Nombre_UQ_Tentativo11,
																		@Nombre_UQ_Tentativo12,
																		@Nombre_UQ_Tentativo13,
																		@Nombre_UQ_Tentativo14,
																		@Nombre_UQ_Tentativo15,
																		@Nombre_UQ_Tentativo16,
																		@Nombre_UQ_Tentativo17,
																		@Nombre_UQ_Tentativo18,
																		@Nombre_UQ_Tentativo19,
																		@Nombre_UQ_Tentativo20,
																		@Nombre_UQ_Tentativo21,
																		@Nombre_UQ_Tentativo22,
																		@Nombre_UQ_Tentativo23,
																		@Nombre_UQ_Tentativo24 )
									BEGIN
										SELECT @existe_UQ = 'S'
									END
									--
								END
								--
						END
						--
					CLOSE C_Armar_UQ
					--
					DEALLOCATE C_Armar_UQ
					--
					--
					IF @Campo_Clave4 != ''
					BEGIN
						SELECT @Nombre_UQ_Tentativo1  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_UQ_Tentativo2  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo3  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_UQ_Tentativo4  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo5  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo6  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						--                                                                                                            
						SELECT @Nombre_UQ_Tentativo7  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_UQ_Tentativo8  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo9  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_UQ_Tentativo10 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_UQ_Tentativo11 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo12 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						--                                                                                                            
						SELECT @Nombre_UQ_Tentativo13 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_UQ_Tentativo14 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo15 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_UQ_Tentativo16 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_UQ_Tentativo17 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo18 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
						--                                                                                                            
						SELECT @Nombre_UQ_Tentativo19 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo20 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo21 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo22 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_UQ_Tentativo23 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo24 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					END
					ELSE IF @Campo_Clave3 != ''
					BEGIN
						SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo3 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_UQ_Tentativo4 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_UQ_Tentativo5 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_UQ_Tentativo6 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
					END
					ELSE IF @Campo_Clave2 != ''
					BEGIN
						SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					END
					ELSE IF @Campo_Clave1 != ''
					BEGIN
						SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1
					END
					--
					IF @Nombre_UQ IN (	@Nombre_UQ_Tentativo1 ,
														@Nombre_UQ_Tentativo2 ,
														@Nombre_UQ_Tentativo3 ,
														@Nombre_UQ_Tentativo4 ,
														@Nombre_UQ_Tentativo5 ,
														@Nombre_UQ_Tentativo6 ,
														@Nombre_UQ_Tentativo7 ,
														@Nombre_UQ_Tentativo8 ,
														@Nombre_UQ_Tentativo9 ,
														@Nombre_UQ_Tentativo10,
														@Nombre_UQ_Tentativo11,
														@Nombre_UQ_Tentativo12,
														@Nombre_UQ_Tentativo13,
														@Nombre_UQ_Tentativo14,
														@Nombre_UQ_Tentativo15,
														@Nombre_UQ_Tentativo16,
														@Nombre_UQ_Tentativo17,
														@Nombre_UQ_Tentativo18,
														@Nombre_UQ_Tentativo19,
														@Nombre_UQ_Tentativo20,
														@Nombre_UQ_Tentativo21,
														@Nombre_UQ_Tentativo22,
														@Nombre_UQ_Tentativo23,
														@Nombre_UQ_Tentativo24 )
					BEGIN
						SELECT @existe_UQ = 'S'
					END
					--
					END
					IF @existe_UQ = 'N'
					BEGIN
						SELECT @error = 'S'
					END
				--
				--
				IF @error = 'S'
				BEGIN
					INSERT INTO @Lista_Unique VALUES (@Nombre_UQ)
				END
				--
				--
				FETCH NEXT FROM C_Objetos_UQ
					INTO @Nombre_UQ, @Nom_Tabla_UQ
					--
				END
				--
		CLOSE C_Objetos_UQ
		--
		DEALLOCATE C_Objetos_UQ
		--
		--
		SELECT Nom_Unique as 'Unique fuera de norma' 
		FROM @Lista_Unique				 
		--						 
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'C')  /* CHECK */
BEGIN
		--
		DECLARE C_Objetos_CK CURSOR FOR
			SELECT obj.name, tab.name
			FROM sys.objects AS obj
					INNER JOIN sys.tables AS tab
						ON obj.parent_object_id = tab.object_id
			WHERE obj.type = 'C'
		--
		DECLARE @Lista_Check TABLE(Nom_check NVARCHAR(max))
		--
		DECLARE @Nombre_CK					VARCHAR(250)
		DECLARE @Nom_Tabla_CK				VARCHAR(110)
		--
		OPEN C_Objetos_CK
			FETCH NEXT FROM C_Objetos_CK 
				INTO @Nombre_CK, @Nom_Tabla_CK
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				--
				SELECT @error = 'N'
				--
				IF LEFT( @Nombre_CK, 3 ) != 'CK' + CHAR(95)
				BEGIN
					SELECT @error = 'S'
				END
				ELSE
				BEGIN
					--
					DECLARE @Nom_Campo_Check			VARCHAR(50)
					DECLARE @Nom_Constraint_CK			VARCHAR(250)
					DECLARE @Nom_Constraint_CK_Ant	VARCHAR(250)
					--
					SELECT  @Num = 0
					--
					DECLARE @Primero_CK					INT
					SELECT  @Primero_CK = 1
					--
					SELECT @Campo_Clave1					= ''
					SELECT @Campo_Clave2					= ''
					SELECT @Campo_Clave3					= ''
					SELECT @Campo_Clave4					= ''
					--
					DECLARE @Nombre_CK_Tentativo1 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo2 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo3 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo4 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo5 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo6 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo7 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo8 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo9 	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo10	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo11	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo12	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo13	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo14	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo15	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo16	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo17	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo18	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo19	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo20	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo21	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo22	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo23	VARCHAR(300)
					DECLARE @Nombre_CK_Tentativo24	VARCHAR(300)
					--
					SELECT @Nombre_CK_Tentativo1 	= ''
					SELECT @Nombre_CK_Tentativo2 	= ''
					SELECT @Nombre_CK_Tentativo3 	= ''
					SELECT @Nombre_CK_Tentativo4 	= ''
					SELECT @Nombre_CK_Tentativo5 	= ''
					SELECT @Nombre_CK_Tentativo6 	= ''
					SELECT @Nombre_CK_Tentativo7 	= ''
					SELECT @Nombre_CK_Tentativo8 	= ''
					SELECT @Nombre_CK_Tentativo9 	= ''
					SELECT @Nombre_CK_Tentativo10	= ''
					SELECT @Nombre_CK_Tentativo11	= ''
					SELECT @Nombre_CK_Tentativo12	= ''
					SELECT @Nombre_CK_Tentativo13	= ''
					SELECT @Nombre_CK_Tentativo14	= ''
					SELECT @Nombre_CK_Tentativo15	= ''
					SELECT @Nombre_CK_Tentativo16	= ''
					SELECT @Nombre_CK_Tentativo17	= ''
					SELECT @Nombre_CK_Tentativo18	= ''
					SELECT @Nombre_CK_Tentativo19	= ''
					SELECT @Nombre_CK_Tentativo20	= ''
					SELECT @Nombre_CK_Tentativo21	= ''
					SELECT @Nombre_CK_Tentativo22	= ''
					SELECT @Nombre_CK_Tentativo23	= ''
					SELECT @Nombre_CK_Tentativo24	= ''
					--
					DECLARE @existe_CK 	CHAR(1)
					SELECT @existe_CK = 'N'
					--
					--Obtener los campos asociados a la CK:
					DECLARE C_Armar_CK CURSOR 
					FOR
						--
						SELECT col.constraint_name, col.column_name
						FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE col 
							INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tab
								ON tab.constraint_name = col.constraint_name 
						WHERE tab.table_name = @Nom_Tabla_CK
						  AND tab.constraint_type = 'CHECK' 
						ORDER BY tab.constraint_name
						--
						--
					OPEN C_Armar_CK
						FETCH NEXT FROM C_Armar_CK
							INTO @Nom_Constraint_CK, @Nom_Campo_Check
							--
						WHILE @@FETCH_STATUS = 0
						BEGIN
							--
							IF @Primero_CK = 1
							BEGIN
								SELECT @Nom_Constraint_CK_Ant = @Nom_Constraint_CK
								SELECT @Primero_CK = 0
							END
							--
							IF @Nom_Constraint_CK = @Nom_Constraint_CK_Ant
							BEGIN
								--
								SELECT @Num = @Num + 1
								SELECT @Nom_Constraint_CK_Ant = @Nom_Constraint_CK
								--
								IF @Nom_Campo_Check != ''
								BEGIN
									IF @Num = 1
									BEGIN
										SELECT @Campo_Clave1 = @Nom_Campo_Check
									END
									ELSE IF @Num = 2
									BEGIN
										SELECT @Campo_Clave2 = @Nom_Campo_Check
									END
									ELSE IF @Num = 3
									BEGIN
										SELECT @Campo_Clave3 = @Nom_Campo_Check
									END
									ELSE IF @Num = 4
									BEGIN
										SELECT @Campo_Clave4 = @Nom_Campo_Check
									END
									--
								END
								--
							END
							ELSE
							BEGIN
								SELECT @Primero_CK = 1
								SELECT @Num = 0
								--
							END
							--
							FETCH NEXT FROM C_Armar_CK
								INTO @Nom_Constraint_CK, @Nom_Campo_Check
								--
								IF @Nom_Constraint_CK != @Nom_Constraint_CK_Ant
								BEGIN
									SELECT @Primero_CK = 1
									SELECT @Num = 0
									--
									IF @Campo_Clave4 != ''
									BEGIN
										SELECT @Nombre_CK_Tentativo1  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_CK_Tentativo2  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo3  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_CK_Tentativo4  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo5  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo6  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
										--                                                                                                            
										SELECT @Nombre_CK_Tentativo7  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_CK_Tentativo8  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo9  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_CK_Tentativo10 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_CK_Tentativo11 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo12 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
										--                                                                                                            
										SELECT @Nombre_CK_Tentativo13 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_CK_Tentativo14 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo15 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
										SELECT @Nombre_CK_Tentativo16 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_CK_Tentativo17 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo18 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
										--                                                                                                            
										SELECT @Nombre_CK_Tentativo19 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo20 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo21 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo22 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_CK_Tentativo23 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo24 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
									END
									ELSE IF @Campo_Clave3 != ''
									BEGIN
										SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo3 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
										SELECT @Nombre_CK_Tentativo4 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_CK_Tentativo5 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
										SELECT @Nombre_CK_Tentativo6 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
									END
									ELSE IF @Campo_Clave2 != ''
									BEGIN
										SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
										SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
									END
									ELSE IF @Campo_Clave1 != ''
									BEGIN
										SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1
									END
									--
									IF @Nombre_CK IN (	@Nombre_CK_Tentativo1 ,
																		@Nombre_CK_Tentativo2 ,
																		@Nombre_CK_Tentativo3 ,
																		@Nombre_CK_Tentativo4 ,
																		@Nombre_CK_Tentativo5 ,
																		@Nombre_CK_Tentativo6 ,
																		@Nombre_CK_Tentativo7 ,
																		@Nombre_CK_Tentativo8 ,
																		@Nombre_CK_Tentativo9 ,
																		@Nombre_CK_Tentativo10,
																		@Nombre_CK_Tentativo11,
																		@Nombre_CK_Tentativo12,
																		@Nombre_CK_Tentativo13,
																		@Nombre_CK_Tentativo14,
																		@Nombre_CK_Tentativo15,
																		@Nombre_CK_Tentativo16,
																		@Nombre_CK_Tentativo17,
																		@Nombre_CK_Tentativo18,
																		@Nombre_CK_Tentativo19,
																		@Nombre_CK_Tentativo20,
																		@Nombre_CK_Tentativo21,
																		@Nombre_CK_Tentativo22,
																		@Nombre_CK_Tentativo23,
																		@Nombre_CK_Tentativo24 )
									BEGIN
										SELECT @existe_CK = 'S'
									END
									--
								END
								--
						END
						--
					CLOSE C_Armar_CK
					--
					DEALLOCATE C_Armar_CK
					--
					--
					IF @Campo_Clave4 != ''
					BEGIN
						SELECT @Nombre_CK_Tentativo1  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_CK_Tentativo2  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo3  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_CK_Tentativo4  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo5  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo6  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						--                                                                                                            
						SELECT @Nombre_CK_Tentativo7  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_CK_Tentativo8  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo9  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_CK_Tentativo10 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_CK_Tentativo11 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo12 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						--                                                                                                            
						SELECT @Nombre_CK_Tentativo13 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_CK_Tentativo14 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo15 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
						SELECT @Nombre_CK_Tentativo16 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_CK_Tentativo17 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo18 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
						--                                                                                                            
						SELECT @Nombre_CK_Tentativo19 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo20 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo21 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo22 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_CK_Tentativo23 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo24 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					END
					ELSE IF @Campo_Clave3 != ''
					BEGIN
						SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo3 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
						SELECT @Nombre_CK_Tentativo4 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_CK_Tentativo5 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
						SELECT @Nombre_CK_Tentativo6 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
					END
					ELSE IF @Campo_Clave2 != ''
					BEGIN
						SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
						SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					END
					ELSE IF @Campo_Clave1 != ''
					BEGIN
						SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1
					END
					--
					IF @Nombre_CK IN (	@Nombre_CK_Tentativo1 ,
														@Nombre_CK_Tentativo2 ,
														@Nombre_CK_Tentativo3 ,
														@Nombre_CK_Tentativo4 ,
														@Nombre_CK_Tentativo5 ,
														@Nombre_CK_Tentativo6 ,
														@Nombre_CK_Tentativo7 ,
														@Nombre_CK_Tentativo8 ,
														@Nombre_CK_Tentativo9 ,
														@Nombre_CK_Tentativo10,
														@Nombre_CK_Tentativo11,
														@Nombre_CK_Tentativo12,
														@Nombre_CK_Tentativo13,
														@Nombre_CK_Tentativo14,
														@Nombre_CK_Tentativo15,
														@Nombre_CK_Tentativo16,
														@Nombre_CK_Tentativo17,
														@Nombre_CK_Tentativo18,
														@Nombre_CK_Tentativo19,
														@Nombre_CK_Tentativo20,
														@Nombre_CK_Tentativo21,
														@Nombre_CK_Tentativo22,
														@Nombre_CK_Tentativo23,
														@Nombre_CK_Tentativo24 )
					BEGIN
						SELECT @existe_CK = 'S'
					END
					--
					END
					IF @existe_CK = 'N'
					BEGIN
						SELECT @error = 'S'
					END
				--
				--
				IF @error = 'S'
				BEGIN
					INSERT INTO @Lista_Check VALUES (@Nombre_CK)
				END
				--
				--
				FETCH NEXT FROM C_Objetos_CK
					INTO @Nombre_CK, @Nom_Tabla_CK
					--
				END
				--
		CLOSE C_Objetos_CK
		--
		DEALLOCATE C_Objetos_CK
		--
		--
		SELECT Nom_check as 'Check fuera de norma' 
		FROM @Lista_Check				 
		--						 
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'FK')  /* FOREIGN KEY */
BEGIN
		--
		DECLARE C_Objetos_FK CURSOR FOR
			SELECT obj.name, tab.name
			FROM sys.objects AS obj
					INNER JOIN sys.tables AS tab
						ON obj.parent_object_id = tab.object_id
			WHERE obj.type = 'F'
		--
		DECLARE @Lista_ForeignKey TABLE(Nom_Foreign NVARCHAR(max))
		--
		DECLARE @Nombre_FK					VARCHAR(250)
		DECLARE @Nom_Tabla_FK				VARCHAR(110)
		--
		DECLARE @Prefijo_Tabla1				VARCHAR(150)
		DECLARE @Nom_Despues_Seg_Guion1	VARCHAR(150)
		DECLARE @Nombre_Tabla1				VARCHAR(150)
		DECLARE @Tabla2						VARCHAR(150)
		DECLARE @Prefijo_Tabla2				VARCHAR(150)
		DECLARE @Nom_Despues_Seg_Guion2	VARCHAR(150)
		DECLARE @Nombre_Tabla2				TABLE(NombreTentativo VARCHAR(200))
		--
		OPEN C_Objetos_FK
			FETCH NEXT FROM C_Objetos_FK 
				INTO @Nombre_FK, @Nom_Tabla_FK
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				--
				SELECT @error = 'N'
				--
				SELECT @Prefijo_Tabla1				= SUBSTRING (@Nombre_FK, 4, 3)
				SELECT @Nom_Despues_Seg_Guion1	= REPLACE (@Nombre_FK, LEFT (@Nombre_FK, 7), '')
				SELECT @Nombre_Tabla1 = ''
				--
				IF LEFT( @Nombre_FK, 3 ) != 'FK' + CHAR(95)
				BEGIN
					SET @error = 'S'
				END
				ELSE
				BEGIN
					IF CHARINDEX(CHAR(95), @Nom_Despues_Seg_Guion1) != 0
					BEGIN
						SET @Nombre_Tabla1 = SUBSTRING (@Nom_Despues_Seg_Guion1, 1, CHARINDEX (CHAR(95), @Nom_Despues_Seg_Guion1) - 1)
					END
				END
				--
				SET @Tabla2 = REPLACE (@Nombre_FK, 'FK' + CHAR(95) + @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1 + CHAR(95), '')
				--
				DECLARE C_Armar_FK CURSOR 
				FOR
					SELECT name
					FROM sys.tables
					WHERE object_id = (
										SELECT referenced_object_id
										FROM sys.foreign_keys
										WHERE parent_object_id = (	
																	SELECT object_id
																	FROM sys.tables
																	WHERE name LIKE @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1
																  )
										)
				--
				DECLARE @NombreTablaRef VARCHAR(200)
				--
				OPEN C_Armar_FK
					FETCH NEXT FROM C_Armar_FK
						INTO @NombreTablaRef
						--
					WHILE @@FETCH_STATUS = 0
					BEGIN
						--
						INSERT INTO @Nombre_Tabla2 VALUES ('FK_' + @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1 + CHAR(95) + @NombreTablaRef)
						--
						FETCH NEXT FROM C_Armar_FK
							INTO @NombreTablaRef
					END
					--
				CLOSE C_Armar_FK
				--
				DEALLOCATE C_Armar_FK
				--
				IF @Nombre_FK NOT IN (	SELECT NombreTentativo
														FROM @Nombre_Tabla2 )
				BEGIN
					SET @error = 'S'
				END
				--
				--
				IF @error = 'S'
				BEGIN
					INSERT INTO @Lista_ForeignKey VALUES (@Nombre_FK)
				END
				--
				--
				FETCH NEXT FROM C_Objetos_FK
					INTO @Nombre_FK, @Nom_Tabla_FK
					--
				END
				--
		CLOSE C_Objetos_FK
		--
		DEALLOCATE C_Objetos_FK
		--
		--
		SELECT Nom_Foreign as 'Foreign Key fuera de norma' 
		FROM @Lista_ForeignKey				 
		--						 
END
--
--
ELSE IF (UPPER(@varTipoObjeto) = 'I')	/* INDICES */				
		BEGIN
			DECLARE itest cursor for
				select t.name as ntabla, i.name as nindice 
					from sys.indexes i
					join sys.tables t
					on i.object_id = t.object_id
					and i.name not in (select name from sys.objects
							   WHERE type in ('C', 'F', 'PK', 'UQ' ))
		
			DECLARE @listaindices TABLE(nindice nvarchar(max))
			DECLARE @ntabla nvarchar(max)
			DECLARE @nindice nvarchar(max)
			DECLARE @largo INT
			DECLARE @mistring nvarchar(max)
			DECLARE @nombrein varchar(max)
			
			open itest
			fetch next from itest into @ntabla, @nindice
			while @@fetch_status = 0
				begin
		
				set @largo = LEN ('ix'+CHAR(95)+@ntabla)
				
				set @mistring = SUBSTRING (@nindice, 1, @largo)
				
				set @nombrein = REPLACE(@nindice, @mistring + CHAR(95), '')
					
					if (@mistring + CHAR(95) <> 'ix'+ CHAR(95)+ @ntabla + CHAR(95))
					     OR (left(@nombrein,1) = lower(left(@nombrein,1))  )		
						BEGIN
						INSERT INTO @listaindices VALUES (@nindice)
			
					END
			
				fetch next from itest
				into @ntabla, @nindice
				end
			close itest
			deallocate itest
			
			select nindice as 'Indices fuera de norma' from @listaindices

		END
								
END