CREATE FUNCTION f_Valida_Normas
(
	@varNombreObjeto VARCHAR(255),
	@varTipoObjeto	 VARCHAR(50)
)
RETURNS INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Resultado INT
	DECLARE @LenPrefijo INT
	DECLARE @LenTerminoUno INT
	DECLARE @NombreObjetoSinPrefijo INT
	DECLARE @varTipoObjetoExiste CHAR(2)
	DECLARE @Error CHAR(1)
	SELECT @Error = 'N'
	
	DECLARE @Num				INT
	SELECT  @Num = 0
	--
	DECLARE @Primero			INT
	SELECT  @Primero = 1
	DECLARE @Campo_Clave1		VARCHAR(50)
	DECLARE @Campo_Clave2		VARCHAR(50)
	DECLARE @Campo_Clave3		VARCHAR(50)
	DECLARE @Campo_Clave4		VARCHAR(50)
	
	DECLARE @Prefijos TABLE(prefijo CHAR(3))
	INSERT INTO @Prefijos VALUES ('ARQ'),('GEN'),('MKT'),('PRT'),('PVN'),('RSV'),('SYA'),('TMP'),('WEB')

	-- Add the T-SQL statements to compute the return value here
	SET @varTipoObjeto = UPPER(@varTipoObjeto)
	SET @varTipoObjetoExiste =	CASE @varTipoObjeto
									WHEN 'T' THEN 'U'
									WHEN 'FK' THEN 'F'
									WHEN 'U' THEN 'UQ'
									ELSE @varTipoObjeto
								END
								
	IF @varTipoObjeto = 'I'
	BEGIN
		IF NOT EXISTS (
						SELECT 1
						FROM sys.indexes
						WHERE name = @varNombreObjeto
					   )
		BEGIN
			SET @Resultado = -1
		END
	END
	ELSE
	BEGIN
		IF NOT EXISTS (
						SELECT 1
						FROM sys.objects
						WHERE name = @varNombreObjeto
						AND type = @varTipoObjetoExiste
					  )
		BEGIN
			SET @Resultado = -1
		END
	END
-----------------------------------------------------------------------------------------------------------
IF (@Resultado != -1) OR (@Resultado IS NULL)
BEGIN
	IF @varTipoObjeto = 'V' /************************************/
	BEGIN
		IF (LEFT (@varNombreObjeto,2) = 'v' + CHAR(95) AND
			SUBSTRING (@varNombreObjeto, 3, 3) IN (SELECT prefijo FROM @Prefijos) AND
			SUBSTRING (@varNombreObjeto, 7, 1) = UPPER (SUBSTRING (@varNombreObjeto, 7, 1)))
		BEGIN
			SET @Resultado = 0
		END
		ELSE
		BEGIN
			SET @Resultado = 1
		END
	END
	
	ELSE IF @varTipoObjeto = 'P' /************************************/
	BEGIN
		IF (LEFT (@varNombreObjeto, 2) = 'p' + CHAR(95) AND
			SUBSTRING (@varNombreObjeto, 3, 3) IN (SELECT prefijo FROM @Prefijos) AND
			SUBSTRING (@varNombreObjeto, 6, 1) = CHAR(95) AND
			SUBSTRING (@varNombreObjeto, 7, 1) = UPPER (SUBSTRING (@varNombreObjeto, 7, 1)))
		BEGIN
			SELECT @Resultado = 0
		END
		ELSE
		BEGIN
			SELECT @Resultado = 1
		END
	END
	
	ELSE IF @varTipoObjeto = 'I' /************************************/
	BEGIN
				DECLARE @largo INT
				DECLARE @nombre nvarchar(max)
				DECLARE @mistring nvarchar(max)
				
				DECLARE @ntabla nvarchar(max)
				DECLARE @nindice nvarchar(max)
				DECLARE @nombrein nvarchar(max)
				
				/*   SE DECLARA TABLA TEMPORAL PARA RELACIONAR EL INDICE CON
        				LA TABLA A LA QUE ESTA ASOCIADO Y ASI PODER VALIDAR			*/
			        	
				DECLARE @listaindices TABLE(nindice nvarchar(max), ntabla nvarchar(max))
				INSERT INTO @listaindices (nindice, ntabla)
				   SELECT i.name as nindice ,
						  t.name  as ntabla
						from sys.indexes i
							join sys.tables t
								on i.object_id = t.object_id
						where i.name = @varNombreObjeto	
						and i.name not in (select name from sys.objects
										   WHERE type in ('C', 'F', 'PK', 'UQ' ))
			      
					SELECT @ntabla = ntabla FROM @listaindices
					SELECT @nindice = nindice FROM @listaindices
					
					SET @largo = LEN ('ix'+CHAR(95)+@ntabla)
					SET @mistring = SUBSTRING (@nindice, 1, @largo)
					SET @nombrein = REPLACE(@nindice, @mistring + CHAR(95), '')
					
					IF (@mistring + CHAR(95) = 'ix'+ CHAR(95)+ @ntabla + CHAR(95)) AND
						(left(@nombrein,1) = upper(left(@nombrein,1))  )		
					BEGIN
						SET @Resultado = 0
					END	
				ELSE
					BEGIN
						SET @Resultado = 1
					END
	END
	
	ELSE IF @varTipoObjeto = 'T' /************************************/
	BEGIN
		IF (SUBSTRING (@varNombreObjeto,1,3) IN ('ARQ', 'GEN', 'MKT', 'PRT', 'PVN', 'RSV', 'SYA', 'TMP', 'WEB') AND
			(SUBSTRING (@varNombreObjeto,4,1) = '_') AND
			(SUBSTRING (@varNombreObjeto, 5, 1) = UPPER(SUBSTRING(@varNombreObjeto, 5, 1))))
		BEGIN
			SET @Resultado = 0
		END
		ELSE
		BEGIN
			SET @Resultado = 1
		END
	  --END
	END
---------------------------------
	ELSE IF @varTipoObjeto = 'TR' /************************************/
	BEGIN
		--
		DECLARE @Pos_Pri_Guion 					INT
		DECLARE @Nom_Ant_Pri_Guion 			VARCHAR(50)
		DECLARE @Nom_Hasta_Pri_Guion 			VARCHAR(50)
		DECLARE @Primer_Guion					CHAR(1)
		DECLARE @Nom_Despues_Pri_Guion 		VARCHAR(50)
		DECLARE @Prefijo_Tabla 					VARCHAR(50)
		DECLARE @Guion_Des_Prefijo 			CHAR(1)
		DECLARE @NomTabla_Guion_Descripcion VARCHAR(50)
		DECLARE @Nom_Tabla 						VARCHAR(50)
		DECLARE @Ultimo_Guion 					VARCHAR(50)
		DECLARE @Descripcion_Trigger 			VARCHAR(50)
		--
		SELECT @Pos_Pri_Guion 					= CHARINDEX( CHAR(95), @varNombreObjeto )
		SELECT @Nom_Ant_Pri_Guion 				= SUBSTRING( @varNombreObjeto, 0, @Pos_Pri_Guion )
		SELECT @Nom_Hasta_Pri_Guion 			= SUBSTRING( @varNombreObjeto, 0, @Pos_Pri_Guion + 1 )
		SELECT @Primer_Guion 					= SUBSTRING( @Nom_Hasta_Pri_Guion, CHARINDEX( CHAR(95), @Nom_Hasta_Pri_Guion ),1 )
		SELECT @Nom_Despues_Pri_Guion 		= REPLACE( @varNombreObjeto, @Nom_Hasta_Pri_Guion, '' )
		SELECT @Prefijo_Tabla 					= SUBSTRING( @Nom_Despues_Pri_Guion, 1, 3 )
		SELECT @Guion_Des_Prefijo 				= SUBSTRING( @Nom_Despues_Pri_Guion, 4, 1 )
		SELECT @NomTabla_Guion_Descripcion 	= REPLACE( @Nom_Despues_Pri_Guion, @Prefijo_Tabla + CHAR(95), '' )
		SELECT @Nom_Tabla 						= SUBSTRING( @NomTabla_Guion_Descripcion, 0, CHARINDEX( CHAR(95), @NomTabla_Guion_Descripcion) )
		SELECT @Descripcion_Trigger 			= REPLACE( REPLACE ( @NomTabla_Guion_Descripcion, @Nom_Tabla, '' ), CHAR(95), '' )
		SELECT @Ultimo_Guion 					= REPLACE( REPLACE( @NomTabla_Guion_Descripcion, @Nom_Tabla, '' ), @Descripcion_Trigger, '' )
		--
		SELECT @Error = 'N'
		--
		--
		--Validación de la hasta el primer "_" (Inclusive) del nombre del Trigger
		IF	LEFT( @varNombreObjeto, 2 ) = 'TR' AND
			LEN( REPLACE( @Nom_Ant_Pri_Guion, 'TR', '') ) <= 3 AND
			@Primer_Guion = CHAR(95)
		BEGIN
			--
			DECLARE @letra_1 CHAR(1) 
			DECLARE @letra_2 CHAR(1)
			DECLARE @letra_3 CHAR(1)
			--
			SELECT @letra_1 = SUBSTRING( REPLACE( @Nom_Ant_Pri_Guion, 'TR', ''),1, 1)
			SELECT @letra_2 = SUBSTRING( REPLACE( @Nom_Ant_Pri_Guion, 'TR', ''),2, 1)
			SELECT @letra_3 = SUBSTRING( REPLACE( @Nom_Ant_Pri_Guion, 'TR', ''),3, 1)
			--
			IF @letra_1 NOT IN ('I','D','U')
			BEGIN
				SELECT @Error = 'S'
			END
			ELSE
			BEGIN
				IF @letra_2 != ''
				BEGIN
					IF @letra_2 NOT IN('I','D','U') OR @letra_2 = @letra_1
					BEGIN
						SELECT @Error = 'S'
					END
					ELSE
					BEGIN
						IF @letra_3 != ''
						BEGIN
							IF @letra_3 NOT IN('I','D','U') OR @letra_3 = @letra_1 OR @letra_3 = @letra_2
							BEGIN
								SELECT @Error = 'S'
							END
						END
					END
				END
			END
		END
		ELSE
		BEGIN
			SELECT @Error = 'S'
		END	
		--
		--
		IF @Error = 'N'
		BEGIN
			--Se valida que exista el nombre del Trigger, asociado a la tabla:
			DECLARE C_TR_Tabla CURSOR 
			FOR
				SELECT COUNT(1)
				FROM sys.objects AS obj
				WHERE type = 'TR'
				  AND obj.name = @varNombreObjeto
				  AND parent_object_id IN (	SELECT tab.object_id
											FROM sys.tables AS tab
											WHERE tab.name = @Prefijo_Tabla + CHAR(95) + @Nom_Tabla );		 
			--
			DECLARE @Nom_TR_Valido INT
			--
			OPEN C_TR_Tabla
				FETCH NEXT FROM C_TR_Tabla
					INTO @Nom_TR_Valido
				WHILE @@FETCH_STATUS = 0
				BEGIN
					--
					FETCH NEXT FROM C_TR_Tabla
						INTO @Nom_TR_Valido
				END
			CLOSE C_TR_Tabla
			
			DEALLOCATE C_TR_Tabla
			--
			--
			IF	@Nom_TR_Valido = 0 OR
				@Ultimo_Guion != CHAR(95) OR
				LEFT( @Descripcion_Trigger, 1 ) != UPPER( LEFT( @Descripcion_Trigger, 1 ) )
			BEGIN
				SELECT @Error = 'S'
				--
			END
			
		END
		--
		--
		IF @Error = 'S'
		BEGIN
			SELECT @Resultado = 1
		END
		ELSE
		BEGIN
			SELECT @Resultado = 0
		END
		END
--------------------------------
	ELSE IF @varTipoObjeto = 'FK' /************************************/
	BEGIN
	--
	DECLARE @Prefijo_Tabla1				VARCHAR(150)
	DECLARE @Nom_Despues_Seg_Guion1		VARCHAR(150)
	DECLARE @Nombre_Tabla1				VARCHAR(150)
	DECLARE @Tabla2						VARCHAR(150)
	DECLARE @Prefijo_Tabla2				VARCHAR(150)
	DECLARE @Nom_Despues_Seg_Guion2		VARCHAR(150)
	DECLARE @Nombre_Tabla2				TABLE(NombreTentativo VARCHAR(200))
	--
	SELECT @Prefijo_Tabla1				= SUBSTRING (@varNombreObjeto, 4, 3)
	SELECT @Nom_Despues_Seg_Guion1		= REPLACE (@varNombreObjeto, LEFT (@varNombreObjeto, 7), '')
	SELECT @Nombre_Tabla1 = ''
	--
	IF LEFT( @varNombreObjeto, 3 ) != 'FK' + CHAR(95)
	BEGIN
		SET @Error = 'S'
	END
	ELSE
	BEGIN
		IF CHARINDEX(CHAR(95), @Nom_Despues_Seg_Guion1) != 0
		BEGIN
			SET @Nombre_Tabla1 = SUBSTRING (@Nom_Despues_Seg_Guion1, 1, CHARINDEX (CHAR(95), @Nom_Despues_Seg_Guion1) - 1)
		END
	END
	--
	SET @Tabla2 = REPLACE (@varNombreObjeto, 'FK' + CHAR(95) + @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1 + CHAR(95), '')
	--
	SET @Error = 'N'
	--
		--Se valida que exista el nombre de la FK, asociado a la tabla:
		DECLARE @Existe_FK INT
		SET @Existe_FK = (
							SELECT COUNT(1)
							FROM sys.objects AS obj
							WHERE type = 'F'
							  AND obj.name = @varNombreObjeto
							  AND parent_object_id IN (	
														SELECT tab.object_id
														FROM sys.tables AS tab
														WHERE tab.name = @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1
													   )
						  )
		--
		IF @Existe_FK = 0
		BEGIN
			SET @Error = 'S'
		END
		ELSE
		BEGIN
		
			DECLARE C_Armar_FK CURSOR 
			FOR
				SELECT name
				FROM sys.tables
				WHERE object_id = (
									SELECT referenced_object_id
									FROM sys.foreign_keys
									WHERE parent_object_id = (	
																SELECT object_id
																FROM sys.tables
																WHERE name LIKE @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1
															  )
								   )
				DECLARE @NombreTablaRef VARCHAR(200)
			OPEN C_Armar_FK
					FETCH NEXT FROM C_Armar_FK
						INTO @NombreTablaRef
			WHILE @@FETCH_STATUS = 0
			BEGIN
				INSERT INTO @Nombre_Tabla2 VALUES ('FK_' + @Prefijo_Tabla1 + CHAR(95) + @Nombre_Tabla1 + CHAR(95) + @NombreTablaRef)
				FETCH NEXT FROM C_Armar_FK
					INTO @NombreTablaRef
			END
			CLOSE C_Armar_FK
			--
			DEALLOCATE C_Armar_FK
				--
			
			IF @varNombreObjeto NOT IN (
											SELECT NombreTentativo
											FROM @Nombre_Tabla2
										)
			BEGIN
				SET @Error = 'S'
			END
	END
	IF @Error = 'S'
	BEGIN
		SET @Resultado = 1
	END
	ELSE
	BEGIN
		SET @Resultado = 0
	END
	END

	ELSE IF @varTipoObjeto = 'PK' /************************************/
	BEGIN
		DECLARE @Prefijo_Tabla_PK				VARCHAR(150)
		DECLARE @Nom_Despues_Seg_Guion		VARCHAR(150)
		DECLARE @Nombre_Tabla				VARCHAR(150)
		--
		SELECT @Prefijo_Tabla_PK				= SUBSTRING( @varNombreObjeto, 4, 3 )
		SELECT @Nom_Despues_Seg_Guion		= REPLACE( @varNombreObjeto, LEFT( @varNombreObjeto, 7 ), '' )
		SELECT @Nombre_Tabla = ''
		--
		IF CHARINDEX( CHAR(95), REPLACE( @varNombreObjeto, LEFT( @varNombreObjeto, 7 ), '' ) ) != 0
		BEGIN
			SELECT @Nombre_Tabla			= SUBSTRING( REPLACE( @varNombreObjeto, LEFT( @varNombreObjeto, 7 ), '' ), 1, CHARINDEX( CHAR(95), REPLACE( @varNombreObjeto, LEFT( @varNombreObjeto, 7 ), '' ) ) - 1 )	
		END
		
		
		--
		SELECT @Error = 'N'
		--
		--
		IF LEFT( @varNombreObjeto, 3 ) != 'PK' + CHAR(95)
		BEGIN
			SELECT @Error = 'S'
		END
		ELSE
		BEGIN
			--
			--Se valida que exista el nombre de la PK, asociado a la tabla:
			DECLARE C_PK_Tabla CURSOR 
			FOR
				SELECT COUNT(1)
				FROM sys.objects AS obj
				WHERE type = 'PK'
				  AND obj.name = @varNombreObjeto
				  AND parent_object_id IN (	SELECT tab.object_id
														FROM sys.tables AS tab
														WHERE tab.name = @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla );		 
			--
			DECLARE @Existe_PK INT
			--
			OPEN C_PK_Tabla
				FETCH NEXT FROM C_PK_Tabla
					INTO @Existe_PK
				WHILE @@FETCH_STATUS = 0
				BEGIN
					--
					FETCH NEXT FROM C_PK_Tabla
						INTO @Existe_PK
				END
			CLOSE C_PK_Tabla
			--
			DEALLOCATE C_PK_Tabla
			--
			IF @Existe_PK = 0
			BEGIN
				SELECT @Error = 'S'
			END
			ELSE
			BEGIN
				--
				--Obtener los campos clave de la tabla:
				DECLARE C_Armar_PK CURSOR 
				FOR
					SELECT name
					FROM sys.columns 
					WHERE object_id IN (	SELECT object_id 
												FROM sys.objects 
												WHERE name = @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla )
					  AND column_id IN (	SELECT SIK.column_id 
												FROM sys.index_columns SIK 
														INNER JOIN sys.objects SO 
															ON SIK.object_id = SO.object_id
												WHERE SIK.index_id = 1 
												  AND SO.name = @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla)	 
				--
				DECLARE @Nom_Campo_Clave	VARCHAR(250)
				--
				SELECT @Num = 0
				--
				--
				OPEN C_Armar_PK
					FETCH NEXT FROM C_Armar_PK
						INTO @Nom_Campo_Clave
						--
					WHILE @@FETCH_STATUS = 0
					BEGIN
						--
						SELECT @Num = @Num + 1
						--
						IF @Nom_Campo_Clave != ''
						BEGIN
							IF @Num = 1
							BEGIN
								SELECT @Campo_Clave1 = @Nom_Campo_Clave
							END
							ELSE IF @Num = 2
							BEGIN
								SELECT @Campo_Clave2 = @Nom_Campo_Clave
							END
							ELSE IF @Num = 3
							BEGIN
								SELECT @Campo_Clave3 = @Nom_Campo_Clave
							END
							ELSE IF @Num = 4
							BEGIN
								SELECT @Campo_Clave4 = @Nom_Campo_Clave
							END
							--
						END
						--
						FETCH NEXT FROM C_Armar_PK
							INTO @Nom_Campo_Clave
							--
					END
				CLOSE C_Armar_PK
				--
				DEALLOCATE C_Armar_PK
				--
				DECLARE @Nombre_PK_Tentativo1 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo2 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo3 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo4 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo5 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo6 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo7 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo8 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo9 	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo10	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo11	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo12	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo13	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo14	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo15	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo16	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo17	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo18	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo19	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo20	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo21	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo22	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo23	VARCHAR(300)
				DECLARE @Nombre_PK_Tentativo24	VARCHAR(300)
				--
				SELECT @Nombre_PK_Tentativo1 	= ''
				SELECT @Nombre_PK_Tentativo2 	= ''
				SELECT @Nombre_PK_Tentativo3 	= ''
				SELECT @Nombre_PK_Tentativo4 	= ''
				SELECT @Nombre_PK_Tentativo5 	= ''
				SELECT @Nombre_PK_Tentativo6 	= ''
				SELECT @Nombre_PK_Tentativo7 	= ''
				SELECT @Nombre_PK_Tentativo8 	= ''
				SELECT @Nombre_PK_Tentativo9 	= ''
				SELECT @Nombre_PK_Tentativo10	= ''
				SELECT @Nombre_PK_Tentativo11	= ''
				SELECT @Nombre_PK_Tentativo12	= ''
				SELECT @Nombre_PK_Tentativo13	= ''
				SELECT @Nombre_PK_Tentativo14	= ''
				SELECT @Nombre_PK_Tentativo15	= ''
				SELECT @Nombre_PK_Tentativo16	= ''
				SELECT @Nombre_PK_Tentativo17	= ''
				SELECT @Nombre_PK_Tentativo18	= ''
				SELECT @Nombre_PK_Tentativo19	= ''
				SELECT @Nombre_PK_Tentativo20	= ''
				SELECT @Nombre_PK_Tentativo21	= ''
				SELECT @Nombre_PK_Tentativo22	= ''
				SELECT @Nombre_PK_Tentativo23	= ''
				SELECT @Nombre_PK_Tentativo24	= ''
				--
				IF @Campo_Clave4 != ''
				BEGIN
					SELECT @Nombre_PK_Tentativo1  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
					SELECT @Nombre_PK_Tentativo2  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo3  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
					SELECT @Nombre_PK_Tentativo4  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo5  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo6  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
					--                                                                                                                                                                   
					SELECT @Nombre_PK_Tentativo7  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
					SELECT @Nombre_PK_Tentativo8  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo9  = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
					SELECT @Nombre_PK_Tentativo10 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
					SELECT @Nombre_PK_Tentativo11 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo12 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
					--                                                                                                                                                                   
					SELECT @Nombre_PK_Tentativo13 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
					SELECT @Nombre_PK_Tentativo14 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo15 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
					SELECT @Nombre_PK_Tentativo16 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
					SELECT @Nombre_PK_Tentativo17 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo18 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					--                                                                                                                                                                   
					SELECT @Nombre_PK_Tentativo19 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo20 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo21 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo22 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
					SELECT @Nombre_PK_Tentativo23 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo24 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
				END
				ELSE IF @Campo_Clave3 != ''
				BEGIN
					SELECT @Nombre_PK_Tentativo1 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo2 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo3 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
					SELECT @Nombre_PK_Tentativo4 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
					SELECT @Nombre_PK_Tentativo5 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
					SELECT @Nombre_PK_Tentativo6 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				END
				ELSE IF @Campo_Clave2 != ''
				BEGIN
					SELECT @Nombre_PK_Tentativo1 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
					SELECT @Nombre_PK_Tentativo2 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
				END
				ELSE IF @Campo_Clave1 != ''
				BEGIN
					SELECT @Nombre_PK_Tentativo1 = 'PK_' + @Prefijo_Tabla_PK + CHAR(95) + @Nombre_Tabla + CHAR(95) + @Campo_Clave1
				END
				--
				--
				IF @varNombreObjeto NOT IN (	@Nombre_PK_Tentativo1 ,
														@Nombre_PK_Tentativo2 ,
														@Nombre_PK_Tentativo3 ,
														@Nombre_PK_Tentativo4 ,
														@Nombre_PK_Tentativo5 ,
														@Nombre_PK_Tentativo6 ,
														@Nombre_PK_Tentativo7 ,
														@Nombre_PK_Tentativo8 ,
														@Nombre_PK_Tentativo9 ,
														@Nombre_PK_Tentativo10,
														@Nombre_PK_Tentativo11,
														@Nombre_PK_Tentativo12,
														@Nombre_PK_Tentativo13,
														@Nombre_PK_Tentativo14,
														@Nombre_PK_Tentativo15,
														@Nombre_PK_Tentativo16,
														@Nombre_PK_Tentativo17,
														@Nombre_PK_Tentativo18,
														@Nombre_PK_Tentativo19,
														@Nombre_PK_Tentativo20,
														@Nombre_PK_Tentativo21,
														@Nombre_PK_Tentativo22,
														@Nombre_PK_Tentativo23,
														@Nombre_PK_Tentativo24 )
				BEGIN
					SELECT @Error = 'S'
				END
				--
			END
			--
		END
		--
		IF @Error = 'S'
			SET @Resultado = 1
		ELSE
			SET @Resultado = 0
	END
	--
	ELSE IF @varTipoObjeto = 'C' /************************************/
	BEGIN
	IF LEFT( @varNombreObjeto, 3 ) != 'CK' + CHAR(95)
	BEGIN
		SELECT @Error = 'S'
	END
	ELSE
	BEGIN
		--
		--Se recupera el nombre de la tabla asociado al nombre de la CK:
		DECLARE C_Tabla_CK CURSOR 
		FOR
			SELECT tab.name
			FROM sys.tables AS tab
			WHERE tab.object_id IN (
												SELECT obj.parent_object_id
												FROM sys.objects AS obj
												WHERE type = 'C'
												  AND obj.name = @varNombreObjeto
											)		 
		--
		DECLARE @Nom_Tabla_CK VARCHAR(50)
		--
		OPEN C_Tabla_CK
			FETCH NEXT FROM C_Tabla_CK
				--
				INTO @Nom_Tabla_CK
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				FETCH NEXT FROM C_Tabla_CK
					INTO @Nom_Tabla_CK
			END
		CLOSE C_Tabla_CK
		--
		DEALLOCATE C_Tabla_CK
		--
		--
		IF @Nom_Tabla_CK = ''
		BEGIN
			SELECT @Error = 'S'
		END
		ELSE
		BEGIN
			--
			DECLARE @Nom_Campo_Check			VARCHAR(50)
			DECLARE @Nom_Constraint_CK			VARCHAR(250)
			DECLARE @Nom_Constraint_CK_Ant	VARCHAR(250)
			--
			SELECT @Campo_Clave1					= ''
			SELECT @Campo_Clave2					= ''
			SELECT @Campo_Clave3					= ''
			SELECT @Campo_Clave4					= ''
			--
			DECLARE @Nombre_CK_Tentativo1 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo2 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo3 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo4 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo5 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo6 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo7 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo8 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo9 	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo10	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo11	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo12	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo13	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo14	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo15	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo16	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo17	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo18	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo19	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo20	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo21	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo22	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo23	VARCHAR(300)
			DECLARE @Nombre_CK_Tentativo24	VARCHAR(300)
			--
			SELECT @Nombre_CK_Tentativo1 	= ''
			SELECT @Nombre_CK_Tentativo2 	= ''
			SELECT @Nombre_CK_Tentativo3 	= ''
			SELECT @Nombre_CK_Tentativo4 	= ''
			SELECT @Nombre_CK_Tentativo5 	= ''
			SELECT @Nombre_CK_Tentativo6 	= ''
			SELECT @Nombre_CK_Tentativo7 	= ''
			SELECT @Nombre_CK_Tentativo8 	= ''
			SELECT @Nombre_CK_Tentativo9 	= ''
			SELECT @Nombre_CK_Tentativo10	= ''
			SELECT @Nombre_CK_Tentativo11	= ''
			SELECT @Nombre_CK_Tentativo12	= ''
			SELECT @Nombre_CK_Tentativo13	= ''
			SELECT @Nombre_CK_Tentativo14	= ''
			SELECT @Nombre_CK_Tentativo15	= ''
			SELECT @Nombre_CK_Tentativo16	= ''
			SELECT @Nombre_CK_Tentativo17	= ''
			SELECT @Nombre_CK_Tentativo18	= ''
			SELECT @Nombre_CK_Tentativo19	= ''
			SELECT @Nombre_CK_Tentativo20	= ''
			SELECT @Nombre_CK_Tentativo21	= ''
			SELECT @Nombre_CK_Tentativo22	= ''
			SELECT @Nombre_CK_Tentativo23	= ''
			SELECT @Nombre_CK_Tentativo24	= ''
			--
			DECLARE @existe_CK 	CHAR(1)
			SELECT @existe_CK = 'N'
			--
			--Obtener los campos asociados a la CK:
			DECLARE C_Armar_CK CURSOR 
			FOR
				--
				SELECT col.constraint_name, col.column_name
				FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE col 
					INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tab
						ON tab.constraint_name = col.constraint_name 
				WHERE tab.table_name = @Nom_Tabla_CK
				  AND tab.constraint_type = 'CHECK' 
				ORDER BY tab.constraint_name
				--
				--
			OPEN C_Armar_CK
				FETCH NEXT FROM C_Armar_CK
					INTO @Nom_Constraint_CK, @Nom_Campo_Check
					--
				WHILE @@FETCH_STATUS = 0
				BEGIN
					--
					IF @Primero = 1
					BEGIN
						SELECT @Nom_Constraint_CK_Ant = @Nom_Constraint_CK
						SELECT @Primero = 0
					END
					--
					IF @Nom_Constraint_CK = @Nom_Constraint_CK_Ant
					BEGIN
						--
						SELECT @Num = @Num + 1
						SELECT @Nom_Constraint_CK_Ant = @Nom_Constraint_CK
						--
						IF @Nom_Campo_Check != ''
						BEGIN
							IF @Num = 1
							BEGIN
								SELECT @Campo_Clave1 = @Nom_Campo_Check
							END
							ELSE IF @Num = 2
							BEGIN
								SELECT @Campo_Clave2 = @Nom_Campo_Check
							END
							ELSE IF @Num = 3
							BEGIN
								SELECT @Campo_Clave3 = @Nom_Campo_Check
							END
							ELSE IF @Num = 4
							BEGIN
								SELECT @Campo_Clave4 = @Nom_Campo_Check
							END
							--
						END
						--
					END
					ELSE
					BEGIN
						SELECT @Primero = 1
						SELECT @Num = 0
						--
					END
					--
					FETCH NEXT FROM C_Armar_CK
						INTO @Nom_Constraint_CK, @Nom_Campo_Check
						--
						IF @Nom_Constraint_CK != @Nom_Constraint_CK_Ant
						BEGIN
							SELECT @Primero = 1
							SELECT @Num = 0
							--
							IF @Campo_Clave4 != ''
							BEGIN
								SELECT @Nombre_CK_Tentativo1  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_CK_Tentativo2  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo3  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_CK_Tentativo4  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo5  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo6  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
								--                                                                                                            
								SELECT @Nombre_CK_Tentativo7  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_CK_Tentativo8  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo9  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_CK_Tentativo10 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_CK_Tentativo11 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo12 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
								--                                                                                                            
								SELECT @Nombre_CK_Tentativo13 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_CK_Tentativo14 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo15 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_CK_Tentativo16 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_CK_Tentativo17 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo18 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
								--                                                                                                            
								SELECT @Nombre_CK_Tentativo19 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo20 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo21 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo22 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_CK_Tentativo23 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo24 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
							END
							ELSE IF @Campo_Clave3 != ''
							BEGIN
								SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo3 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_CK_Tentativo4 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_CK_Tentativo5 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_CK_Tentativo6 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
							END
							ELSE IF @Campo_Clave2 != ''
							BEGIN
								SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
							END
							ELSE IF @Campo_Clave1 != ''
							BEGIN
								SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1
							END
							--
							IF @varNombreObjeto IN (	@Nombre_CK_Tentativo1 ,
																@Nombre_CK_Tentativo2 ,
																@Nombre_CK_Tentativo3 ,
																@Nombre_CK_Tentativo4 ,
																@Nombre_CK_Tentativo5 ,
																@Nombre_CK_Tentativo6 ,
																@Nombre_CK_Tentativo7 ,
																@Nombre_CK_Tentativo8 ,
																@Nombre_CK_Tentativo9 ,
																@Nombre_CK_Tentativo10,
																@Nombre_CK_Tentativo11,
																@Nombre_CK_Tentativo12,
																@Nombre_CK_Tentativo13,
																@Nombre_CK_Tentativo14,
																@Nombre_CK_Tentativo15,
																@Nombre_CK_Tentativo16,
																@Nombre_CK_Tentativo17,
																@Nombre_CK_Tentativo18,
																@Nombre_CK_Tentativo19,
																@Nombre_CK_Tentativo20,
																@Nombre_CK_Tentativo21,
																@Nombre_CK_Tentativo22,
																@Nombre_CK_Tentativo23,
																@Nombre_CK_Tentativo24 )
							BEGIN
								SELECT @existe_CK = 'S'
							END
							--
						END
						--
				END
				--
			CLOSE C_Armar_CK
			--
			DEALLOCATE C_Armar_CK
			--
			--
			IF @Campo_Clave4 != ''
			BEGIN
				SELECT @Nombre_CK_Tentativo1  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_CK_Tentativo2  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo3  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_CK_Tentativo4  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo5  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo6  = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
				--                                                                                                            
				SELECT @Nombre_CK_Tentativo7  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_CK_Tentativo8  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo9  = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_CK_Tentativo10 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_CK_Tentativo11 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo12 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
				--                                                                                                            
				SELECT @Nombre_CK_Tentativo13 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_CK_Tentativo14 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo15 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_CK_Tentativo16 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_CK_Tentativo17 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo18 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
				--                                                                                                            
				SELECT @Nombre_CK_Tentativo19 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo20 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo21 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo22 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_CK_Tentativo23 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo24 = 'CK_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
			END
			ELSE IF @Campo_Clave3 != ''
			BEGIN
				SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo3 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_CK_Tentativo4 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_CK_Tentativo5 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_CK_Tentativo6 = 'CK_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
			END
			ELSE IF @Campo_Clave2 != ''
			BEGIN
				SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_CK_Tentativo2 = 'CK_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
			END
			ELSE IF @Campo_Clave1 != ''
			BEGIN
				SELECT @Nombre_CK_Tentativo1 = 'CK_' + @Campo_Clave1
			END
			--
			IF @varNombreObjeto IN (	@Nombre_CK_Tentativo1 ,
												@Nombre_CK_Tentativo2 ,
												@Nombre_CK_Tentativo3 ,
												@Nombre_CK_Tentativo4 ,
												@Nombre_CK_Tentativo5 ,
												@Nombre_CK_Tentativo6 ,
												@Nombre_CK_Tentativo7 ,
												@Nombre_CK_Tentativo8 ,
												@Nombre_CK_Tentativo9 ,
												@Nombre_CK_Tentativo10,
												@Nombre_CK_Tentativo11,
												@Nombre_CK_Tentativo12,
												@Nombre_CK_Tentativo13,
												@Nombre_CK_Tentativo14,
												@Nombre_CK_Tentativo15,
												@Nombre_CK_Tentativo16,
												@Nombre_CK_Tentativo17,
												@Nombre_CK_Tentativo18,
												@Nombre_CK_Tentativo19,
												@Nombre_CK_Tentativo20,
												@Nombre_CK_Tentativo21,
												@Nombre_CK_Tentativo22,
												@Nombre_CK_Tentativo23,
												@Nombre_CK_Tentativo24 )
			BEGIN
				SELECT @existe_CK = 'S'
			END
			--
		END
		--
	END
	--
	--
	IF @existe_CK = 'N'
	BEGIN
		SELECT @Error = 'S'
	END
	--
	--
	IF @Error = 'S'
	BEGIN
		SELECT @Resultado = 1
	END
	ELSE
	BEGIN
		SELECT @Resultado = 0
	END
	END
--------------------------------xyz
ELSE IF @varTipoObjeto = 'UQ' /************************************/
BEGIN
	IF LEFT( @varNombreObjeto, 3 ) != 'UQ' + CHAR(95)
	BEGIN
		SELECT @Error = 'S'
	END
	ELSE
	BEGIN
		--
		--Se recupera el nombre de la tabla asociado al nombre de la UQ:
		DECLARE C_Tabla_UQ CURSOR 
		FOR
			SELECT tab.name
			FROM sys.tables AS tab
			WHERE tab.object_id IN (
												SELECT obj.parent_object_id
												FROM sys.objects AS obj
												WHERE type = 'UQ'
												  AND obj.name = @varNombreObjeto
											)		 
		--
		DECLARE @Nom_Tabla_UQ VARCHAR(50)
		--
		OPEN C_Tabla_UQ
			FETCH NEXT FROM C_Tabla_UQ
				--
				INTO @Nom_Tabla_UQ
				--
			WHILE @@FETCH_STATUS = 0
			BEGIN
				FETCH NEXT FROM C_Tabla_UQ
					INTO @Nom_Tabla_UQ
			END
		CLOSE C_Tabla_UQ
		--
		DEALLOCATE C_Tabla_UQ
		--
		--
		IF @Nom_Tabla_UQ = ''
		BEGIN
			SELECT @Error = 'S'
		END
		ELSE
		BEGIN
			--
			DECLARE @Nom_Campo_Unique			VARCHAR(50)
			DECLARE @Nom_Constraint_UQ			VARCHAR(250)
			DECLARE @Nom_Constraint_UQ_Ant	VARCHAR(250)
			--

			--

			--
			SELECT @Campo_Clave1					= ''
			SELECT @Campo_Clave2					= ''
			SELECT @Campo_Clave3					= ''
			SELECT @Campo_Clave4					= ''
			--
			DECLARE @Nombre_UQ_Tentativo1 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo2 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo3 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo4 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo5 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo6 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo7 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo8 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo9 	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo10	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo11	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo12	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo13	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo14	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo15	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo16	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo17	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo18	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo19	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo20	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo21	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo22	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo23	VARCHAR(300)
			DECLARE @Nombre_UQ_Tentativo24	VARCHAR(300)
			--
			SELECT @Nombre_UQ_Tentativo1 	= ''
			SELECT @Nombre_UQ_Tentativo2 	= ''
			SELECT @Nombre_UQ_Tentativo3 	= ''
			SELECT @Nombre_UQ_Tentativo4 	= ''
			SELECT @Nombre_UQ_Tentativo5 	= ''
			SELECT @Nombre_UQ_Tentativo6 	= ''
			SELECT @Nombre_UQ_Tentativo7 	= ''
			SELECT @Nombre_UQ_Tentativo8 	= ''
			SELECT @Nombre_UQ_Tentativo9 	= ''
			SELECT @Nombre_UQ_Tentativo10	= ''
			SELECT @Nombre_UQ_Tentativo11	= ''
			SELECT @Nombre_UQ_Tentativo12	= ''
			SELECT @Nombre_UQ_Tentativo13	= ''
			SELECT @Nombre_UQ_Tentativo14	= ''
			SELECT @Nombre_UQ_Tentativo15	= ''
			SELECT @Nombre_UQ_Tentativo16	= ''
			SELECT @Nombre_UQ_Tentativo17	= ''
			SELECT @Nombre_UQ_Tentativo18	= ''
			SELECT @Nombre_UQ_Tentativo19	= ''
			SELECT @Nombre_UQ_Tentativo20	= ''
			SELECT @Nombre_UQ_Tentativo21	= ''
			SELECT @Nombre_UQ_Tentativo22	= ''
			SELECT @Nombre_UQ_Tentativo23	= ''
			SELECT @Nombre_UQ_Tentativo24	= ''
			--
			DECLARE @existe_UQ 	CHAR(1)
			SELECT @existe_UQ = 'N'
			--
			--Obtener los campos asociados a la UQ:
			DECLARE C_Armar_UQ CURSOR 
			FOR
				--
				SELECT col.constraint_name, col.column_name
				FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE col 
					INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tab
						ON tab.constraint_name = col.constraint_name 
				WHERE tab.table_name = @Nom_Tabla_UQ
				  AND tab.constraint_type = 'UNIQUE' 
				ORDER BY tab.constraint_name
				--
				--
			OPEN C_Armar_UQ
				FETCH NEXT FROM C_Armar_UQ
					INTO @Nom_Constraint_UQ, @Nom_Campo_Unique
					--
				WHILE @@FETCH_STATUS = 0
				BEGIN
					--
					IF @Primero = 1
					BEGIN
						SELECT @Nom_Constraint_UQ_Ant = @Nom_Constraint_UQ
						SELECT @Primero = 0
					END
					--
					IF @Nom_Constraint_UQ = @Nom_Constraint_UQ_Ant
					BEGIN
						--
						SELECT @Num = @Num + 1
						SELECT @Nom_Constraint_UQ_Ant = @Nom_Constraint_UQ
						--
						IF @Nom_Campo_Unique != ''
						BEGIN
							IF @Num = 1
							BEGIN
								SELECT @Campo_Clave1 = @Nom_Campo_Unique
							END
							ELSE IF @Num = 2
							BEGIN
								SELECT @Campo_Clave2 = @Nom_Campo_Unique
							END
							ELSE IF @Num = 3
							BEGIN
								SELECT @Campo_Clave3 = @Nom_Campo_Unique
							END
							ELSE IF @Num = 4
							BEGIN
								SELECT @Campo_Clave4 = @Nom_Campo_Unique
							END
							--
						END
						--
					END
					ELSE
					BEGIN
						SELECT @Primero = 1
						SELECT @Num = 0
						--
					END
					--
					FETCH NEXT FROM C_Armar_UQ
						INTO @Nom_Constraint_UQ, @Nom_Campo_Unique
						--
						IF @Nom_Constraint_UQ != @Nom_Constraint_UQ_Ant
						BEGIN
							SELECT @Primero = 1
							SELECT @Num = 0
							--
							IF @Campo_Clave4 != ''
							BEGIN
								SELECT @Nombre_UQ_Tentativo1  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_UQ_Tentativo2  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo3  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_UQ_Tentativo4  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo5  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo6  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
								--                                                                                                            
								SELECT @Nombre_UQ_Tentativo7  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_UQ_Tentativo8  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo9  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_UQ_Tentativo10 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_UQ_Tentativo11 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo12 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
								--                                                                                                            
								SELECT @Nombre_UQ_Tentativo13 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_UQ_Tentativo14 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo15 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
								SELECT @Nombre_UQ_Tentativo16 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_UQ_Tentativo17 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo18 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
								--                                                                                                            
								SELECT @Nombre_UQ_Tentativo19 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo20 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo21 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo22 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_UQ_Tentativo23 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo24 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
							END
							ELSE IF @Campo_Clave3 != ''
							BEGIN
								SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo3 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
								SELECT @Nombre_UQ_Tentativo4 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_UQ_Tentativo5 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
								SELECT @Nombre_UQ_Tentativo6 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
							END
							ELSE IF @Campo_Clave2 != ''
							BEGIN
								SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
								SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
							END
							ELSE IF @Campo_Clave1 != ''
							BEGIN
								SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1
							END
							--
							IF @varNombreObjeto IN (	@Nombre_UQ_Tentativo1 ,
																@Nombre_UQ_Tentativo2 ,
																@Nombre_UQ_Tentativo3 ,
																@Nombre_UQ_Tentativo4 ,
																@Nombre_UQ_Tentativo5 ,
																@Nombre_UQ_Tentativo6 ,
																@Nombre_UQ_Tentativo7 ,
																@Nombre_UQ_Tentativo8 ,
																@Nombre_UQ_Tentativo9 ,
																@Nombre_UQ_Tentativo10,
																@Nombre_UQ_Tentativo11,
																@Nombre_UQ_Tentativo12,
																@Nombre_UQ_Tentativo13,
																@Nombre_UQ_Tentativo14,
																@Nombre_UQ_Tentativo15,
																@Nombre_UQ_Tentativo16,
																@Nombre_UQ_Tentativo17,
																@Nombre_UQ_Tentativo18,
																@Nombre_UQ_Tentativo19,
																@Nombre_UQ_Tentativo20,
																@Nombre_UQ_Tentativo21,
																@Nombre_UQ_Tentativo22,
																@Nombre_UQ_Tentativo23,
																@Nombre_UQ_Tentativo24 )
							BEGIN
								SELECT @existe_UQ = 'S'
							END
							--
						END
						--
				END
				--
			CLOSE C_Armar_UQ
			--
			DEALLOCATE C_Armar_UQ
			--
			--
			IF @Campo_Clave4 != ''
			BEGIN
				SELECT @Nombre_UQ_Tentativo1  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_UQ_Tentativo2  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo3  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_UQ_Tentativo4  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo5  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo6  = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
				--                                                                                                            
				SELECT @Nombre_UQ_Tentativo7  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_UQ_Tentativo8  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo9  = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_UQ_Tentativo10 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_UQ_Tentativo11 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo12 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
				--                                                                                                            
				SELECT @Nombre_UQ_Tentativo13 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_UQ_Tentativo14 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo15 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave4
				SELECT @Nombre_UQ_Tentativo16 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_UQ_Tentativo17 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo18 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
				--                                                                                                            
				SELECT @Nombre_UQ_Tentativo19 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo20 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo21 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo22 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_UQ_Tentativo23 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo24 = 'UQ_' + @Campo_Clave4 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
			END
			ELSE IF @Campo_Clave3 != ''
			BEGIN
				SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo3 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave3
				SELECT @Nombre_UQ_Tentativo4 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave3 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_UQ_Tentativo5 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
				SELECT @Nombre_UQ_Tentativo6 = 'UQ_' + @Campo_Clave3 + CHAR(95) + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
			END
			ELSE IF @Campo_Clave2 != ''
			BEGIN
				SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1 + CHAR(95) + @Campo_Clave2
				SELECT @Nombre_UQ_Tentativo2 = 'UQ_' + @Campo_Clave2 + CHAR(95) + @Campo_Clave1
			END
			ELSE IF @Campo_Clave1 != ''
			BEGIN
				SELECT @Nombre_UQ_Tentativo1 = 'UQ_' + @Campo_Clave1
			END
			--
			IF @varNombreObjeto IN (	@Nombre_UQ_Tentativo1 ,
												@Nombre_UQ_Tentativo2 ,
												@Nombre_UQ_Tentativo3 ,
												@Nombre_UQ_Tentativo4 ,
												@Nombre_UQ_Tentativo5 ,
												@Nombre_UQ_Tentativo6 ,
												@Nombre_UQ_Tentativo7 ,
												@Nombre_UQ_Tentativo8 ,
												@Nombre_UQ_Tentativo9 ,
												@Nombre_UQ_Tentativo10,
												@Nombre_UQ_Tentativo11,
												@Nombre_UQ_Tentativo12,
												@Nombre_UQ_Tentativo13,
												@Nombre_UQ_Tentativo14,
												@Nombre_UQ_Tentativo15,
												@Nombre_UQ_Tentativo16,
												@Nombre_UQ_Tentativo17,
												@Nombre_UQ_Tentativo18,
												@Nombre_UQ_Tentativo19,
												@Nombre_UQ_Tentativo20,
												@Nombre_UQ_Tentativo21,
												@Nombre_UQ_Tentativo22,
												@Nombre_UQ_Tentativo23,
												@Nombre_UQ_Tentativo24 )
			BEGIN
				SELECT @existe_UQ = 'S'
			END
			--
		END
		--
	END
	--
	--
	IF @existe_UQ = 'N'
	BEGIN
		SELECT @Error = 'S'
	END
	--
	--
	IF @Error = 'S'
	BEGIN
		SELECT @Resultado = 1
	END
	ELSE
	BEGIN
		SELECT @Resultado = 0
	END
END
--------------------------------
END
	RETURN @Resultado

END